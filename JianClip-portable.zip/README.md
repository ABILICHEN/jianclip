﻿# 简贴 · 袋袋的灵感口袋

Windows 10/11 剪贴板管理器 + 小袋鼠桌宠。复制一下，袋袋替你收好；需要时，随手取用。

[下载最新版本](https://github.com/ABILICHEN/jianclip/releases/latest)

![新版主界面](docs/main-window.png)

![袋袋的动作](assets/kangaroo-poses.png)

## 袋袋会做什么

- **复制入袋**：复制文本或图片，小纸片从鼠标附近飞向袋鼠口袋，袋袋开心跳跃。
- **悬停取用**：停在袋鼠身上约半秒，展开最近 5 条内容（收藏优先），单击即可粘贴到之前的窗口。面板不抢焦点，移开后自动收起。
- **拖放收纳**：选中文字并拖到袋鼠身上即可加入历史；历史列表中的文字也可以拖入袋鼠口袋。暂停记录期间不收纳拖放内容。
- **自由摆放**：按住袋鼠拖动，位置自动保存，兼容负坐标的多显示器桌面。右键可以管理历史、设置提醒、隐藏或退出。
- **动作陪伴**：呼吸、眨眼、挥手、开心跳跃、喝水、远眺、伸懒腰、闲置闭眼。形象用原创矢量代码实时绘制，动作不依赖网络或外部资源。
- **温柔提醒**：默认喝水 45 分钟、远眺 20 分钟；可额外开启起身伸展。间隔可设为 1–240 分钟。支持完成和稍后 10 分钟；22:00–08:00 与连续 5 分钟未操作时安静陪伴。
- **剪贴板管理**：搜索、文本/图片分类、收藏、预览、删除、清空、仅复制、快捷键粘贴、暂停记录、托盘与开机自启。

| 快速口袋 | 陪伴设置 |
| --- | --- |
| ![悬停快速选择面板](docs/quick-panel.png) | ![提醒设置](docs/settings-window.png) |

## 开始使用

1. 从 Release 下载 JianClip-portable.zip，解压到固定目录。也可以仅下载单文件 JianClip.exe。
2. 双击 JianClip.exe，桌面右下角出现黄色小袋鼠。
3. 正常 Ctrl+C / Ctrl+X 复制文本或图片；悬停袋鼠后点选历史，或在输入框按 Ctrl+Alt+V 呼出完整管理器，双击 / Enter 粘贴。
4. 主窗口勾选“开机自启”，下次登录 Windows 后后台启动。移动 EXE 后请取消并重新勾选，更新路径。
5. 关闭主窗口会继续在托盘运行；右键袋鼠或托盘点“退出简贴”结束程序。隐藏袋鼠后可从托盘重新显示。

需要 .NET Framework 4.8（多数 Windows 10/11 已安装），不需要管理员权限，不需要联网。

## 更新旧版

先从旧版托盘退出简贴，再用新 EXE 替换原文件。保留原来的运行路径即可继续使用开机自启。旧版加密历史可直接读取。首次更新如果更换了路径，请重新设置自启。

## 数据与限制

- 历史：%LOCALAPPDATA%/JianClip/history.dat，使用 Windows DPAPI 当前用户加密。设置与位置：同目录 settings.json。内容不会上传至 GitHub，无联网、云同步或遥测代码。
- 最多 200 条、总内容约 1600 万字符；优先移除最旧的非收藏内容。收藏占满时拒收新片段。单张 PNG 上限 4 MB，文本上限 50 万字符。
- 保存纯文本和图片，不保留 HTML/RTF 样式、资源管理器文件复制、OCR 搜索。
- 遵守 ExcludeClipboardContentFromMonitorProcessing 与 CanIncludeInClipboardHistory=0 隐私标记。未带标记的敏感文字仍可能被保存，处理此类内容时可开启暂停记录。
- 自动粘贴受 Windows 前台切换与权限限制；管理员窗口、部分游戏和特殊编辑器可能需要“仅复制”后手动 Ctrl+V。目标窗口发生变化时会保留复制内容并提示手动粘贴。
- “远眺约 20 秒”是提醒文案，不会锁屏或强制倒计时。提醒以本机时间计算，程序关闭期间不计时。夜间安静时段固定为 22:00–08:00，可关闭夜间安静。
- 私有仓库的 Release 仅限有仓库权限的用户下载。

## 构建与验证

运行 build.ps1 编译，test.ps1 执行核心检查，test.ps1 -Integration 执行需要交互桌面的集成检查（临时使用并恢复系统剪贴板）。

使用 Windows 自带 .NET Framework C# 编译器，无 NuGet、Node 或 Python 运行依赖。输出 dist/JianClip.exe。

已通过 22 项核心检查和 7 项桌面集成检查：加密、去重、收藏容量、隐私标记、设置、提醒时序、稍后提醒、透明动作渲染、真实文本与图片剪贴板监听、暂停、程序自身复制去重、快速面板不抢焦点和退出释放。

截图由程序以合成示例内容渲染，未包含用户剪贴板数据。UI 自动化工具在本机还原窗口时报告异常，因此实际鼠标拖放、跨应用自动粘贴及重启登录后的自启仍需用户环境验收。

开发预览：--demo 使用独立临时目录和示例记录，不监听真实剪贴板；--render-preview 输出示例界面 PNG；--export-art 导出七种动作 PNG。这些开发选项不改变正式数据。

## 调研参考

本项目独立实现，没有复制以下项目的代码和美术资源：

- [Ditto](https://github.com/sabrogden/Ditto)：Windows 剪贴板历史。
- [CopyQ](https://github.com/hluk/CopyQ)：剪贴板管理和历史检索。
- [Shijima-Qt](https://github.com/pixelomer/Shijima-Qt)：桌面角色与透明悬浮交互调研参考。
- [desktop-pets](https://github.com/chrisjames432/desktop-pets)：桌宠与提醒组合调研参考。
- [Microsoft 剪贴板监听](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-addclipboardformatlistener) / [隐私标记](https://learn.microsoft.com/en-us/windows/win32/dataxchg/clipboard-formats)。
